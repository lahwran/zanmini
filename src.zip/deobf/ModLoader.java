/**
 * 
 */
package deobf;

/**
 * @author lahwran
 *
 */
public class ModLoader {

    /**
     * @param modZanStarter
     * @param b
     * @param c
     */
    public static void SetInGameHook(BaseMod modZanStarter, boolean b, boolean c) {
        // TODO Auto-generated method stub
        
    }

}
