/**
 * 
 */
package deobf;

/**
 * @author lahwran
 *
 */
public class BaseMod {

    /**
     * @return
     */
    public String Version() {
        // TODO Auto-generated method stub
        return null;
    }

}
